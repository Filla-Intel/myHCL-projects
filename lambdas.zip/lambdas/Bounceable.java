package com.hcl.lambdas;

@FunctionalInterface
// a functional interface
public interface Bounceable<T> {
	
	public boolean test(T obj); // T -> boolean : what you find in a Predicate interface
	
	
	public default void bounceThis() {
		
	}
	
	//public void blah(T obj);

}
