package com.hcl.lambdas;

import java.util.function.Predicate;

public class FunctionalInterfaceClient {

	public static void main(String[] args) {
		Bounceable<String> b1 = new Ball();
		System.out.println(   b1.test("Fred")    );
		
		Bounceable<String> b2 = new Bounceable<String>() { // anonymous inner class
			
			@Override
			public boolean test(String obj) {
				// TODO Auto-generated method stub
				return obj.length() > 1;
			}
		};
		
		System.out.println( "anonymous inner class result: " +   b2.test("Ian")    );
		
		//java.util.function.Predicate
		// T -> boolean
		Bounceable<String> p1 = s -> s.length() > 4; // this is a lambda
		System.out.println("Bouncable version using lambda: " + p1.test("Ricky"));
		
		Predicate<String> p2 = s -> s.length() > 2; // this is a lambda T -> boolean
		
		System.out.println("predicate version: " + p2.test("Lu"));
		

	}

}
